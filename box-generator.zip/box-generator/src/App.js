import './App.css';
import Boxes from './components/Boxes';

function App() {
  return (
    <div className="App">
      <Boxes/>    
    </div>
  );
}

export default App;
